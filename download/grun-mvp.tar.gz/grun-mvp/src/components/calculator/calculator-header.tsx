"use client";

import { LayoutGrid } from "lucide-react";
import type { IndustryPreset } from "@/lib/types";

export function CalculatorHeader({ preset }: { preset: IndustryPreset }) {
  return (
    <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-3">
        <div className="p-2 bg-blue-50 rounded-lg">
          <LayoutGrid className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">{preset.headerTitle}</h1>
          <p className="text-xs text-gray-500">{preset.headerSubtitle}</p>
        </div>
      </div>
    </header>
  );
}
